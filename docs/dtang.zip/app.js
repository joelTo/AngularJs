angular.module('app', [])

.run(function() {
  console.log('PizzaYOLO !');
})

.controller('MyFirstController',function() {    
    this.users = [
        {
            name: 'Thomas'
        },
        {
            name: 'Georges'
        }
    ];
})
