import angular from 'angular';

import { SoundButton } from './sound-button/sound-button.component';

export default angular.module('SoundBox', [])

.component('soundButton', SoundButton)

.name;