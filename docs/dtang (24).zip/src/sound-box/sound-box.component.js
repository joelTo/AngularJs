import css from './sound-box.component.css';

class SoundBoxController {
    constructor() {}

    $onInit() {
        this.sounds = [
{url: "http://localhost:1337/clap-808.wav"},{url: "http://localhost:1337/clap-analog.wav"},{url: "http://localhost:1337/clap-crushed.wav"},{url: "http://localhost:1337/clap-fat.wav"},{url: "http://localhost:1337/clap-slapper.wav"},{url: "http://localhost:1337/clap-tape.wav"},{url: "http://localhost:1337/cowbell-808.wav"},{url: "http://localhost:1337/crash-808.wav"},{url: "http://localhost:1337/crash-acoustic.wav"},{url: "http://localhost:1337/crash-noise.wav"},{url: "http://localhost:1337/crash-tape.wav"},{url: "http://localhost:1337/hihat-808.wav"},{url: "http://localhost:1337/hihat-acoustic01.wav"},{url: "http://localhost:1337/hihat-acoustic02.wav"},{url: "http://localhost:1337/hihat-analog.wav"},{url: "http://localhost:1337/hihat-digital.wav"},{url: "http://localhost:1337/hihat-dist01.wav"},{url: "http://localhost:1337/hihat-dist02.wav"},{url: "http://localhost:1337/hihat-electro.wav"},{url: "http://localhost:1337/hihat-plain.wav"},{url: "http://localhost:1337/hihat-reso.wav"},{url: "http://localhost:1337/hihat-ring.wav"},{url: "http://localhost:1337/kick-808.wav"},{url: "http://localhost:1337/kick-acoustic01.wav"},{url: "http://localhost:1337/kick-acoustic02.wav"},{url: "http://localhost:1337/kick-big.wav"},{url: "http://localhost:1337/kick-classic.wav"},{url: "http://localhost:1337/kick-cultivator.wav"},{url: "http://localhost:1337/kick-deep.wav"},{url: "http://localhost:1337/kick-dry.wav"},{url: "http://localhost:1337/kick-electro01.wav"},{url: "http://localhost:1337/kick-electro02.wav"},{url: "http://localhost:1337/kick-floppy.wav"},{url: "http://localhost:1337/kick-gritty.wav"},{url: "http://localhost:1337/kick-heavy.wav"},{url: "http://localhost:1337/kick-newwave.wav"},{url: "http://localhost:1337/kick-oldschool.wav"},{url: "http://localhost:1337/kick-plain.wav"},{url: "http://localhost:1337/kick-slapback.wav"},{url: "http://localhost:1337/kick-softy.wav"},{url: "http://localhost:1337/kick-stomp.wav"},{url: "http://localhost:1337/kick-tape.wav"},{url: "http://localhost:1337/kick-thump.wav"},{url: "http://localhost:1337/kick-tight.wav"},{url: "http://localhost:1337/kick-tron.wav"},{url: "http://localhost:1337/kick-vinyl01.wav"},{url: "http://localhost:1337/kick-vinyl02.wav"},{url: "http://localhost:1337/kick-zapper.wav"},{url: "http://localhost:1337/openhat-808.wav"},{url: "http://localhost:1337/openhat-acoustic01.wav"},{url: "http://localhost:1337/openhat-analog.wav"},{url: "http://localhost:1337/openhat-slick.wav"},{url: "http://localhost:1337/openhat-tight.wav"},{url: "http://localhost:1337/perc-808.wav"},{url: "http://localhost:1337/perc-chirpy.wav"},{url: "http://localhost:1337/perc-hollow.wav"},{url: "http://localhost:1337/perc-laser.wav"},{url: "http://localhost:1337/perc-metal.wav"},{url: "http://localhost:1337/perc-nasty.wav"},{url: "http://localhost:1337/perc-short.wav"},{url: "http://localhost:1337/perc-tambo.wav"},{url: "http://localhost:1337/perc-tribal.wav"},{url: "http://localhost:1337/perc-weirdo.wav"},{url: "http://localhost:1337/ride-acoustic01.wav"},{url: "http://localhost:1337/ride-acoustic02.wav"},{url: "http://localhost:1337/shaker-analog.wav"},{url: "http://localhost:1337/shaker-shuffle.wav"},{url: "http://localhost:1337/shaker-suckup.wav"},{url: "http://localhost:1337/snare-808.wav"},{url: "http://localhost:1337/snare-acoustic01.wav"},{url: "http://localhost:1337/snare-acoustic02.wav"},{url: "http://localhost:1337/snare-analog.wav"},{url: "http://localhost:1337/snare-big.wav"},{url: "http://localhost:1337/snare-block.wav"},{url: "http://localhost:1337/snare-brute.wav"},{url: "http://localhost:1337/snare-dist01.wav"},{url: "http://localhost:1337/snare-dist02.wav"},{url: "http://localhost:1337/snare-dist03.wav"},{url: "http://localhost:1337/snare-electro.wav"},{url: "http://localhost:1337/snare-lofi01.wav"},{url: "http://localhost:1337/snare-lofi02.wav"},{url: "http://localhost:1337/snare-modular.wav"},{url: "http://localhost:1337/snare-noise.wav"},{url: "http://localhost:1337/snare-pinch.wav"},{url: "http://localhost:1337/snare-punch.wav"},{url: "http://localhost:1337/snare-smasher.wav"},{url: "http://localhost:1337/snare-sumo.wav"},{url: "http://localhost:1337/snare-tape.wav"},{url: "http://localhost:1337/snare-vinyl01.wav"},{url: "http://localhost:1337/snare-vinyl02.wav"},{url: "http://localhost:1337/tom-808.wav"},{url: "http://localhost:1337/tom-acoustic01.wav"},{url: "http://localhost:1337/tom-acoustic02.wav"},{url: "http://localhost:1337/tom-analog.wav"},{url: "http://localhost:1337/tom-chiptune.wav"},{url: "http://localhost:1337/tom-fm.wav"},{url: "http://localhost:1337/tom-lofi.wav"},{url: "http://localhost:1337/tom-rototom.wav"},{url: "http://localhost:1337/tom-short.wav"}


        ];
    }

    delete(sound) {
        this.sounds = this.sounds.filter(s => s !== sound);
    }
}

export const SoundBox = {
    template: `
        <sound-button 
          ng-repeat="sound in $ctrl.sounds track by $index"
          on-delete="$ctrl.delete(sound)" 
          sound="sound">
        </sound-button>
    `,
    controller: SoundBoxController
}